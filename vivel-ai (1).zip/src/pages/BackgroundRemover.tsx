import React, { useState } from 'react';
import { processBackgroundRemoval, loadImage } from '../utils/imageProcessing';
import { BeforeAfterSlider } from '../components/BeforeAfterSlider';
import { SamplePicker } from '../components/SamplePicker';
import { 
  Scissors, 
  Upload, 
  Sparkles, 
  CheckCircle2, 
  Palette, 
  Download, 
  Layers, 
  Image as ImageIcon 
} from 'lucide-react';
import type { BackgroundRemoverSettings } from '../types';

export const BackgroundRemover: React.FC = () => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [imageName, setImageName] = useState<string>('portrait-sample.png');
  const [transparentResult, setTransparentResult] = useState<string | null>(null);
  const [finalProcessedUrl, setFinalProcessedUrl] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Background customization options
  const [bgSettings, setBgSettings] = useState<BackgroundRemoverSettings>({
    bgType: 'transparent',
    color: '#2563eb',
    blurAmount: 10,
    edgeSmoothing: 1,
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageName(file.name);
      const url = URL.createObjectURL(file);
      setImageSrc(url);
      setTransparentResult(null);
      setFinalProcessedUrl(null);
    }
  };

  const handleRemoveBackground = async () => {
    if (!imageSrc) return;
    setIsProcessing(true);

    try {
      const resultUrl = await processBackgroundRemoval(imageSrc);
      setTransparentResult(resultUrl);
      applyBackgroundCustomization(resultUrl, bgSettings);
    } catch (err) {
      console.error('Background removal failed:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const applyBackgroundCustomization = async (
    cutoutSrc: string,
    settings: BackgroundRemoverSettings
  ) => {
    if (!imageSrc || !cutoutSrc) return;

    if (settings.bgType === 'transparent') {
      setFinalProcessedUrl(cutoutSrc);
      return;
    }

    const cutoutImg = await loadImage(cutoutSrc);
    const width = cutoutImg.naturalWidth || cutoutImg.width;
    const height = cutoutImg.naturalHeight || cutoutImg.height;

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d')!;

    if (settings.bgType === 'color') {
      ctx.fillStyle = settings.color;
      ctx.fillRect(0, 0, width, height);
    } else if (settings.bgType === 'blur') {
      const origImg = await loadImage(imageSrc);
      ctx.filter = `blur(${settings.blurAmount}px)`;
      ctx.drawImage(origImg, 0, 0, width, height);
      ctx.filter = 'none';
    }

    // Draw cutout subject on top
    ctx.drawImage(cutoutImg, 0, 0, width, height);
    setFinalProcessedUrl(canvas.toDataURL('image/png'));
  };

  const handleSettingsChange = (newSettings: Partial<BackgroundRemoverSettings>) => {
    const updated = { ...bgSettings, ...newSettings };
    setBgSettings(updated);
    if (transparentResult) {
      applyBackgroundCustomization(transparentResult, updated);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 px-4 py-6">
      {/* Title Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-slate-900 flex items-center justify-center gap-2">
          <Scissors className="w-8 h-8 text-blue-600" />
          <span>Background Remover</span>
        </h1>
        <p className="text-slate-600 text-sm max-w-lg mx-auto">
          Automatically detect subjects and isolate backgrounds with clean edge accuracy for portraits and product photos.
        </p>
      </div>

      {!imageSrc ? (
        <div className="space-y-6">
          {/* File Upload Zone */}
          <div className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-3xl p-12 text-center bg-slate-50 transition-all">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
              id="bg-upload"
            />
            <label htmlFor="bg-upload" className="cursor-pointer space-y-4 inline-block">
              <div className="w-16 h-16 rounded-2xl bg-blue-100 border border-blue-200 text-blue-600 flex items-center justify-center mx-auto shadow-xs">
                <Upload className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-slate-900 font-semibold text-base mb-1">
                  Upload Image to Remove Background
                </h3>
                <p className="text-slate-500 text-xs">Portraits, Products, Objects (PNG, JPG, WebP)</p>
              </div>
              <span className="inline-block bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors shadow-xs">
                Browse Image
              </span>
            </label>
          </div>

          <SamplePicker
            categoryFilter="portrait"
            onSelectSample={(url, name) => {
              setImageName(name);
              setImageSrc(url);
              setTransparentResult(null);
              setFinalProcessedUrl(null);
            }}
          />
        </div>
      ) : (
        <div className="space-y-6">
          {/* Control Bar */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
            
            <div className="flex items-center space-x-3 text-xs text-slate-600">
              <span className="font-semibold text-slate-900">{imageName}</span>
              <button
                onClick={() => setImageSrc(null)}
                className="text-blue-600 hover:underline text-xs"
              >
                Change Image
              </button>
            </div>

            <button
              onClick={handleRemoveBackground}
              disabled={isProcessing}
              className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-6 py-2.5 rounded-xl shadow-xs flex items-center space-x-2 transition-all disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isProcessing ? 'Removing Background...' : 'Remove Background Now'}</span>
            </button>
          </div>

          {/* Original Preview before processing */}
          {!finalProcessedUrl && !isProcessing && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 text-center">
              <h4 className="text-xs text-slate-500 uppercase tracking-wider mb-4 font-semibold">Ready to Remove Background</h4>
              <div className="max-h-[450px] overflow-hidden flex justify-center items-center">
                <img src={imageSrc} alt="Input" className="max-h-[400px] object-contain rounded-xl border border-slate-200" />
              </div>
            </div>
          )}

          {/* Loading Indicator */}
          {isProcessing && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-12 text-center space-y-4">
              <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
              <h3 className="text-slate-900 font-semibold text-base">Segmenting Subject & Background...</h3>
              <p className="text-xs text-slate-500">Isolating foreground details. Please wait a moment.</p>
            </div>
          )}

          {/* Background Customization & Comparison Slider */}
          {finalProcessedUrl && (
            <div className="space-y-6">
              
              {/* Background Options Selector */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-center space-x-2 text-xs font-semibold text-slate-700 uppercase tracking-wider">
                  <Palette className="w-4 h-4 text-blue-600" />
                  <span>Output Background Replacement:</span>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => handleSettingsChange({ bgType: 'transparent' })}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors border ${
                      bgSettings.bgType === 'transparent'
                        ? 'bg-blue-600 border-blue-600 text-white font-bold'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    Transparent PNG
                  </button>

                  <button
                    onClick={() => handleSettingsChange({ bgType: 'color' })}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors border ${
                      bgSettings.bgType === 'color'
                        ? 'bg-blue-600 border-blue-600 text-white font-bold'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    Solid Color
                  </button>

                  <button
                    onClick={() => handleSettingsChange({ bgType: 'blur' })}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors border ${
                      bgSettings.bgType === 'blur'
                        ? 'bg-blue-600 border-blue-600 text-white font-bold'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    Blur Background
                  </button>

                  {/* Color Picker palette */}
                  {bgSettings.bgType === 'color' && (
                    <div className="flex items-center space-x-2 pl-2 border-l border-slate-200">
                      {['#ffffff', '#000000', '#2563eb', '#7c3aed', '#dc2626', '#16a34a'].map((c) => (
                        <button
                          key={c}
                          onClick={() => handleSettingsChange({ color: c })}
                          className={`w-6 h-6 rounded-full border ${
                            bgSettings.color === c ? 'ring-2 ring-blue-600 scale-110' : 'border-slate-300'
                          }`}
                          style={{ backgroundColor: c }}
                        />
                      ))}
                      <input
                        type="color"
                        value={bgSettings.color}
                        onChange={(e) => handleSettingsChange({ color: e.target.value })}
                        className="w-7 h-7 bg-transparent cursor-pointer"
                      />
                    </div>
                  )}

                  {/* Blur Amount Slider */}
                  {bgSettings.bgType === 'blur' && (
                    <div className="flex items-center space-x-2 pl-2 border-l border-slate-200">
                      <span className="text-xs text-slate-600">Blur:</span>
                      <input
                        type="range"
                        min="2"
                        max="30"
                        value={bgSettings.blurAmount}
                        onChange={(e) => handleSettingsChange({ blurAmount: Number(e.target.value) })}
                        className="w-24 accent-blue-600 cursor-pointer"
                      />
                      <span className="text-xs text-slate-800 font-mono">{bgSettings.blurAmount}px</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Before / After Slider */}
              <BeforeAfterSlider
                originalUrl={imageSrc}
                processedUrl={finalProcessedUrl}
                downloadFilename={`no-bg-${imageName}`}
                title="Background Removal Result"
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
};
