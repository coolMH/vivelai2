import React, { useState, useEffect, useCallback } from 'react';
import { processImageResize, loadImage } from '../utils/imageProcessing';
import { SamplePicker } from '../components/SamplePicker';
import { 
  Scaling, 
  Upload, 
  Link as LinkIcon, 
  Unlink, 
  Download, 
  Sparkles, 
  CheckCircle2, 
  Ratio 
} from 'lucide-react';
import type { ResizeSettings } from '../types';

export const ImageResizer: React.FC = () => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [imageName, setImageName] = useState<string>('landscape-sample.png');
  const [imgObj, setImgObj] = useState<HTMLImageElement | null>(null);

  const [originalDimensions, setOriginalDimensions] = useState<{ width: number; height: number; size: number }>({
    width: 0,
    height: 0,
    size: 0,
  });

  const [settings, setSettings] = useState<ResizeSettings>({
    width: 1920,
    height: 1080,
    maintainAspectRatio: true,
    unit: 'px',
    percentage: 100,
    format: 'image/png',
    quality: 0.92,
    scaleMode: 'fit',
  });

  const [processedResult, setProcessedResult] = useState<{
    dataUrl: string;
    width: number;
    height: number;
    size: number;
  } | null>(null);

  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const presets = [
    { label: 'Instagram Post (1:1)', w: 1080, h: 1080 },
    { label: 'Story / Reel (9:16)', w: 1080, h: 1920 },
    { label: 'YouTube Thumbnail (16:9)', w: 1280, h: 720 },
    { label: 'Twitter Header (3:1)', w: 1500, h: 500 },
    { label: 'Passport Photo', w: 600, h: 600 },
    { label: 'Web HD (1920x1080)', w: 1920, h: 1080 },
  ];

  const setupImage = useCallback(async (src: string, fileData?: File) => {
    setImageSrc(src);
    setProcessedResult(null);

    const img = await loadImage(src);
    setImgObj(img);

    const w = img.naturalWidth || img.width;
    const h = img.naturalHeight || img.height;
    const size = fileData ? fileData.size : Math.round(src.length * 0.75);

    setOriginalDimensions({ width: w, height: h, size });
    setSettings((prev) => ({ ...prev, width: w, height: h }));
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageName(file.name);
      const url = URL.createObjectURL(file);
      setupImage(url, file);
    }
  };

  const handleWidthChange = (newWidth: number) => {
    if (!originalDimensions.width) return;
    let newHeight = settings.height;

    if (settings.maintainAspectRatio) {
      const ratio = originalDimensions.height / originalDimensions.width;
      newHeight = Math.round(newWidth * ratio);
    }
    setSettings((prev) => ({ ...prev, width: newWidth, height: newHeight }));
  };

  const handleHeightChange = (newHeight: number) => {
    if (!originalDimensions.height) return;
    let newWidth = settings.width;

    if (settings.maintainAspectRatio) {
      const ratio = originalDimensions.width / originalDimensions.height;
      newWidth = Math.round(newHeight * ratio);
    }
    setSettings((prev) => ({ ...prev, width: newWidth, height: newHeight }));
  };

  const applyPreset = (w: number, h: number) => {
    setSettings((prev) => ({ ...prev, width: w, height: h, maintainAspectRatio: false }));
  };

  const handleProcessResize = async () => {
    if (!imgObj) return;
    setIsProcessing(true);

    try {
      const res = await processImageResize(imgObj, settings);
      setProcessedResult({
        dataUrl: res.dataUrl,
        width: res.width,
        height: res.height,
        size: res.blob.size,
      });
    } catch (err) {
      console.error('Resize error:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 px-4 py-6">
      {/* Title */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-slate-900 flex items-center justify-center gap-2">
          <Scaling className="w-8 h-8 text-blue-600" />
          <span>Image Resizer</span>
        </h1>
        <p className="text-slate-600 text-sm max-w-lg mx-auto">
          Resize images to precise dimensions and convert between PNG, JPEG, and WebP formats without loss of clarity.
        </p>
      </div>

      {!imageSrc ? (
        <div className="space-y-6">
          <div className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-3xl p-12 text-center bg-slate-50 transition-all">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
              id="resizer-upload"
            />
            <label htmlFor="resizer-upload" className="cursor-pointer space-y-4 inline-block">
              <div className="w-16 h-16 rounded-2xl bg-blue-100 border border-blue-200 text-blue-600 flex items-center justify-center mx-auto shadow-xs">
                <Upload className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-slate-900 font-semibold text-base mb-1">
                  Upload Image to Resize
                </h3>
                <p className="text-slate-500 text-xs">Supports PNG, JPG, WebP formats</p>
              </div>
              <span className="inline-block bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors shadow-xs">
                Browse File
              </span>
            </label>
          </div>

          <SamplePicker
            categoryFilter="landscape"
            onSelectSample={(url, name) => {
              setImageName(name);
              setupImage(url);
            }}
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Controls Column */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <span className="text-sm font-bold text-slate-900">Resize Controls</span>
              <button
                onClick={() => setImageSrc(null)}
                className="text-xs text-blue-600 hover:underline"
              >
                Change Image
              </button>
            </div>

            {/* Presets */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Social & Web Presets</label>
              <div className="grid grid-cols-2 gap-2">
                {presets.map((p, idx) => (
                  <button
                    key={idx}
                    onClick={() => applyPreset(p.w, p.h)}
                    className="p-2 text-left bg-white hover:bg-slate-100 border border-slate-200 hover:border-blue-500/60 rounded-lg text-xs transition-colors"
                  >
                    <div className="text-slate-900 font-medium truncate">{p.label}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{p.w} × {p.h} px</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Dimension Inputs */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Dimensions ({settings.unit})</label>
                <button
                  onClick={() => setSettings((s) => ({ ...s, maintainAspectRatio: !s.maintainAspectRatio }))}
                  className={`flex items-center space-x-1 text-xs px-2 py-0.5 rounded border transition-colors ${
                    settings.maintainAspectRatio
                      ? 'bg-blue-50 text-blue-700 border-blue-200 font-semibold'
                      : 'bg-white text-slate-500 border-slate-200'
                  }`}
                  title="Toggle Aspect Ratio Lock"
                >
                  {settings.maintainAspectRatio ? <LinkIcon className="w-3 h-3 text-blue-600" /> : <Unlink className="w-3 h-3" />}
                  <span>{settings.maintainAspectRatio ? 'Aspect Locked' : 'Unlocked'}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3 items-center">
                <div>
                  <label className="text-[11px] text-slate-600 mb-1 block">Width</label>
                  <input
                    type="number"
                    min="1"
                    max="10000"
                    value={settings.width}
                    onChange={(e) => handleWidthChange(Number(e.target.value))}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-900 font-mono text-sm focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-600 mb-1 block">Height</label>
                  <input
                    type="number"
                    min="1"
                    max="10000"
                    value={settings.height}
                    onChange={(e) => handleHeightChange(Number(e.target.value))}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-900 font-mono text-sm focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Scale Fitting & Format */}
            <div className="space-y-3">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Format & Fit</label>
              
              <div className="grid grid-cols-3 gap-2">
                {(['image/png', 'image/jpeg', 'image/webp'] as const).map((fmt) => (
                  <button
                    key={fmt}
                    onClick={() => setSettings((s) => ({ ...s, format: fmt }))}
                    className={`py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                      settings.format === fmt
                        ? 'bg-blue-600 border-blue-600 text-white'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {fmt.replace('image/', '').toUpperCase()}
                  </button>
                ))}
              </div>

              <div className="space-y-1 pt-2">
                <div className="flex justify-between text-xs text-slate-600">
                  <span>Output Quality:</span>
                  <span className="text-slate-900 font-mono font-bold">{Math.round(settings.quality * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="1.0"
                  step="0.05"
                  value={settings.quality}
                  onChange={(e) => setSettings((s) => ({ ...s, quality: Number(e.target.value) }))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>
            </div>

            {/* Submit Button */}
            <button
              onClick={handleProcessResize}
              disabled={isProcessing}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-xs flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isProcessing ? 'Resizing...' : 'Apply Resize'}</span>
            </button>
          </div>

          {/* Preview & Result Column */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 text-center space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-600 pb-3 border-b border-slate-200">
                <span>Original: <strong className="text-slate-900">{originalDimensions.width} × {originalDimensions.height} px</strong> ({formatFileSize(originalDimensions.size)})</span>
                {processedResult && (
                  <span className="text-blue-600 font-semibold">Resized: {processedResult.width} × {processedResult.height} px ({formatFileSize(processedResult.size)})</span>
                )}
              </div>

              <div className="max-h-[500px] overflow-auto flex items-center justify-center p-4 bg-white rounded-xl border border-slate-200">
                <img
                  src={processedResult ? processedResult.dataUrl : imageSrc}
                  alt="Preview"
                  className="max-h-[420px] object-contain rounded-lg shadow-xs"
                />
              </div>

              {processedResult && (
                <div className="pt-2 flex justify-end">
                  <a
                    href={processedResult.dataUrl}
                    download={`resized-${settings.width}x${settings.height}-${imageName}`}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-2.5 rounded-xl shadow-xs flex items-center space-x-2 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Resized Image</span>
                  </a>
                </div>
              )}
            </div>
          </div>

        </div>
      )}
    </div>
  );
};
