import React, { useState, useCallback } from 'react';
import { processImageEnhancement, loadImage } from '../utils/imageProcessing';
import { BeforeAfterSlider } from '../components/BeforeAfterSlider';
import { SamplePicker } from '../components/SamplePicker';
import { 
  SlidersHorizontal, 
  Upload, 
  Sparkles, 
  RotateCcw, 
  Sun, 
  Contrast, 
  Zap, 
  Flame, 
  CheckCircle2 
} from 'lucide-react';
import type { EnhancementSettings } from '../types';

export const ImageEnhancer: React.FC = () => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [imageName, setImageName] = useState<string>('landscape-sample.png');
  const [imgObj, setImgObj] = useState<HTMLImageElement | null>(null);

  const defaultSettings: EnhancementSettings = {
    brightness: 0,
    contrast: 0,
    saturation: 0,
    sharpness: 0,
    temperature: 0,
    blur: 0,
    vibrance: 0,
    vintage: 0,
  };

  const [settings, setSettings] = useState<EnhancementSettings>(defaultSettings);
  const [processedUrl, setProcessedUrl] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const presets: { name: string; settings: Partial<EnhancementSettings>; icon: string }[] = [
    { name: 'HDR Detail Boost', settings: { sharpness: 60, contrast: 25, saturation: 20, brightness: 5 }, icon: '✨' },
    { name: 'Vivid Color', settings: { saturation: 45, brightness: 10, contrast: 15 }, icon: '🎨' },
    { name: 'Crisp Sharpness', settings: { sharpness: 80, contrast: 10 }, icon: '🔪' },
    { name: 'Warm Sunset', settings: { temperature: 35, saturation: 25, brightness: 5 }, icon: '🌅' },
    { name: 'Cool Twilight', settings: { temperature: -30, contrast: 15 }, icon: '🌙' },
    { name: 'Dramatic B&W', settings: { saturation: -100, contrast: 45, sharpness: 40 }, icon: '🎬' },
  ];

  const setupImage = useCallback(async (src: string) => {
    setImageSrc(src);
    const img = await loadImage(src);
    setImgObj(img);
    applyEnhancement(img, defaultSettings);
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageName(file.name);
      const url = URL.createObjectURL(file);
      setupImage(url);
    }
  };

  const applyEnhancement = async (img: HTMLImageElement, currentSettings: EnhancementSettings) => {
    setIsProcessing(true);
    try {
      const result = await processImageEnhancement(img, currentSettings);
      setProcessedUrl(result);
    } catch (err) {
      console.error('Enhancement error:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSliderChange = (key: keyof EnhancementSettings, value: number) => {
    const updated = { ...settings, [key]: value };
    setSettings(updated);
    if (imgObj) {
      applyEnhancement(imgObj, updated);
    }
  };

  const applyPreset = (presetSettings: Partial<EnhancementSettings>) => {
    const updated = { ...defaultSettings, ...presetSettings };
    setSettings(updated);
    if (imgObj) {
      applyEnhancement(imgObj, defaultSettings);
    }
  };

  const resetAll = () => {
    setSettings(defaultSettings);
    if (imgObj) {
      applyEnhancement(imgObj, defaultSettings);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 px-4 py-6">
      {/* Title */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-slate-900 flex items-center justify-center gap-2">
          <SlidersHorizontal className="w-8 h-8 text-blue-600" />
          <span>Image Enhancer</span>
        </h1>
        <p className="text-slate-600 text-sm max-w-lg mx-auto">
          Boost detail, sharpness, color saturation, and contrast for stunning photo clarity.
        </p>
      </div>

      {!imageSrc ? (
        <div className="space-y-6">
          <div className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-3xl p-12 text-center bg-slate-50 transition-all">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
              id="enhancer-upload"
            />
            <label htmlFor="enhancer-upload" className="cursor-pointer space-y-4 inline-block">
              <div className="w-16 h-16 rounded-2xl bg-blue-100 border border-blue-200 text-blue-600 flex items-center justify-center mx-auto shadow-xs">
                <Upload className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-slate-900 font-semibold text-base mb-1">
                  Upload Image to Enhance
                </h3>
                <p className="text-slate-500 text-xs">PNG, JPG, WebP supported</p>
              </div>
              <span className="inline-block bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors shadow-xs">
                Browse Image
              </span>
            </label>
          </div>

          <SamplePicker
            categoryFilter="landscape"
            onSelectSample={(url, name) => {
              setImageName(name);
              setupImage(url);
            }}
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Controls Column */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <span className="text-sm font-bold text-slate-900">Enhancement Controls</span>
              <button
                onClick={resetAll}
                className="text-xs text-slate-500 hover:text-slate-900 flex items-center space-x-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            </div>

            {/* Presets Grid */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Quick Presets</label>
              <div className="grid grid-cols-2 gap-2">
                {presets.map((p, idx) => (
                  <button
                    key={idx}
                    onClick={() => applyPreset(p.settings)}
                    className="p-2 text-left bg-white hover:bg-slate-100 border border-slate-200 hover:border-blue-500/60 rounded-lg text-xs transition-colors flex items-center space-x-2"
                  >
                    <span>{p.icon}</span>
                    <span className="text-slate-900 font-medium truncate">{p.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Sliders */}
            <div className="space-y-4">
              
              {/* Sharpness */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-700">
                  <span className="flex items-center space-x-1">
                    <Zap className="w-3.5 h-3.5 text-blue-600" />
                    <span>Sharpness:</span>
                  </span>
                  <span className="font-mono text-blue-600 font-bold">{settings.sharpness}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.sharpness}
                  onChange={(e) => handleSliderChange('sharpness', Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>

              {/* Brightness */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-700">
                  <span className="flex items-center space-x-1">
                    <Sun className="w-3.5 h-3.5 text-amber-500" />
                    <span>Brightness:</span>
                  </span>
                  <span className="font-mono text-slate-800">{settings.brightness}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.brightness}
                  onChange={(e) => handleSliderChange('brightness', Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>

              {/* Contrast */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-700">
                  <span className="flex items-center space-x-1">
                    <Contrast className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Contrast:</span>
                  </span>
                  <span className="font-mono text-slate-800">{settings.contrast}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.contrast}
                  onChange={(e) => handleSliderChange('contrast', Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>

              {/* Saturation */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-700">
                  <span className="flex items-center space-x-1">
                    <Flame className="w-3.5 h-3.5 text-rose-500" />
                    <span>Saturation:</span>
                  </span>
                  <span className="font-mono text-slate-800">{settings.saturation}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.saturation}
                  onChange={(e) => handleSliderChange('saturation', Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>

              {/* Temperature */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-700">
                  <span>Temperature (Warm / Cool):</span>
                  <span className="font-mono text-slate-800">{settings.temperature}</span>
                </div>
                <input
                  type="range"
                  min="-100"
                  max="100"
                  value={settings.temperature}
                  onChange={(e) => handleSliderChange('temperature', Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setImageSrc(null)}
                className="w-full py-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs rounded-xl font-medium transition-colors"
              >
                Choose Different Image
              </button>
            </div>
          </div>

          {/* Result Column Slider */}
          <div className="lg:col-span-2 space-y-6">
            {processedUrl ? (
              <BeforeAfterSlider
                originalUrl={imageSrc}
                processedUrl={processedUrl}
                downloadFilename={`enhanced-${imageName}`}
                title="AI Enhancement Comparison"
              />
            ) : (
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-12 text-center text-slate-500">
                Enhancing image details...
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
