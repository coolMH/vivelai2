import React, { useState } from 'react';
import { 
  processImageResize, 
  processImageEnhancement, 
  generateZipArchive, 
  loadImage 
} from '../utils/imageProcessing';
import { 
  Layers, 
  Upload, 
  Download, 
  Sparkles, 
  CheckCircle2, 
  Trash2, 
  RefreshCw, 
  FileArchive, 
  Scaling, 
  SlidersHorizontal 
} from 'lucide-react';
import type { ProcessedImage } from '../types';

export const BulkTools: React.FC = () => {
  const [items, setItems] = useState<ProcessedImage[]>([]);
  const [bulkMode, setBulkMode] = useState<'resize' | 'convert' | 'enhance'>('convert');

  // Bulk parameters
  const [targetWidth, setTargetWidth] = useState<number>(1080);
  const [targetHeight, setTargetHeight] = useState<number>(1080);
  const [targetFormat, setTargetFormat] = useState<'image/png' | 'image/jpeg' | 'image/webp'>('image/webp');
  const [quality, setQuality] = useState<number>(0.9);

  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [overallProgress, setOverallProgress] = useState<number>(0);
  const [zipBlob, setZipBlob] = useState<Blob | null>(null);

  const handleMultipleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArr: File[] = Array.from(e.target.files);
      const newItems: ProcessedImage[] = filesArr.map((file, idx) => ({
        id: `bulk-${Date.now()}-${idx}`,
        file,
        originalUrl: URL.createObjectURL(file),
        name: file.name,
        size: file.size,
        type: file.type,
        status: 'idle',
      }));

      setItems((prev) => [...prev, ...newItems]);
      setZipBlob(null);
    }
  };

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
    setZipBlob(null);
  };

  const clearAll = () => {
    setItems([]);
    setZipBlob(null);
    setOverallProgress(0);
  };

  const processBulk = async () => {
    if (items.length === 0) return;
    setIsProcessing(true);
    setOverallProgress(5);
    setZipBlob(null);

    const processedList: { name: string; dataUrl: string }[] = [];

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      
      // Update item status to processing
      setItems((prev) =>
        prev.map((it) => (it.id === item.id ? { ...it, status: 'processing', progress: 50 } : it))
      );

      try {
        const img = await loadImage(item.originalUrl);
        let outputUrl = item.originalUrl;

        if (bulkMode === 'resize') {
          const res = await processImageResize(img, {
            width: targetWidth,
            height: targetHeight,
            maintainAspectRatio: true,
            unit: 'px',
            percentage: 100,
            format: targetFormat,
            quality,
            scaleMode: 'fit',
          });
          outputUrl = res.dataUrl;
        } else if (bulkMode === 'convert') {
          const canvas = document.createElement('canvas');
          canvas.width = img.naturalWidth || img.width;
          canvas.height = img.naturalHeight || img.height;
          const ctx = canvas.getContext('2d')!;
          ctx.drawImage(img, 0, 0);
          outputUrl = canvas.toDataURL(targetFormat, quality);
        } else if (bulkMode === 'enhance') {
          outputUrl = await processImageEnhancement(img, {
            brightness: 10,
            contrast: 15,
            saturation: 25,
            sharpness: 50,
            temperature: 0,
            blur: 0,
            vibrance: 0,
            vintage: 0,
          });
        }

        processedList.push({ name: item.name, dataUrl: outputUrl });

        setItems((prev) =>
          prev.map((it) =>
            it.id === item.id
              ? { ...it, status: 'completed', processedUrl: outputUrl, progress: 100 }
              : it
          )
        );
      } catch (err) {
        setItems((prev) =>
          prev.map((it) =>
            it.id === item.id
              ? { ...it, status: 'error', error: String(err) }
              : it
          )
        );
      }

      setOverallProgress(Math.round(((i + 1) / items.length) * 80));
    }

    // Generate ZIP file
    try {
      const zip = await generateZipArchive(processedList, (zipPercent) => {
        setOverallProgress(80 + Math.round(zipPercent * 0.2));
      });
      setZipBlob(zip);
    } catch (err) {
      console.error('ZIP compilation failed:', err);
    } finally {
      setIsProcessing(false);
      setOverallProgress(100);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 px-4 py-6">
      {/* Title */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-slate-900 flex items-center justify-center gap-2">
          <Layers className="w-8 h-8 text-blue-600" />
          <span>Bulk Tools</span>
        </h1>
        <p className="text-slate-600 text-sm max-w-lg mx-auto">
          Process multiple images simultaneously. Resize, convert formats, enhance, and export a consolidated ZIP archive.
        </p>
      </div>

      {/* Main Workspace */}
      <div className="space-y-6">
        
        {/* Upload Zone & Controls Bar */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 space-y-6">
          
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
            
            {/* Mode Selectors */}
            <div className="flex items-center space-x-2">
              <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider mr-2">Batch Task:</span>
              <button
                onClick={() => setBulkMode('convert')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors ${
                  bulkMode === 'convert' ? 'bg-blue-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Format Convert</span>
              </button>

              <button
                onClick={() => setBulkMode('resize')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors ${
                  bulkMode === 'resize' ? 'bg-blue-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                <Scaling className="w-3.5 h-3.5" />
                <span>Batch Resize</span>
              </button>

              <button
                onClick={() => setBulkMode('enhance')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors ${
                  bulkMode === 'enhance' ? 'bg-blue-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Auto Enhance</span>
              </button>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center space-x-3">
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleMultipleUpload}
                className="hidden"
                id="bulk-file-input"
              />
              <label
                htmlFor="bulk-file-input"
                className="bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold px-4 py-2 rounded-xl cursor-pointer flex items-center space-x-1.5 transition-colors border border-slate-200 shadow-xs"
              >
                <Upload className="w-4 h-4 text-blue-600" />
                <span>Add Images</span>
              </label>

              {items.length > 0 && (
                <button
                  onClick={clearAll}
                  className="text-slate-500 hover:text-rose-600 text-xs px-3 py-2"
                >
                  Clear All
                </button>
              )}
            </div>
          </div>

          {/* Mode Settings Panel */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-wrap items-center gap-6">
            
            {/* Format Picker */}
            <div className="flex items-center space-x-2">
              <span className="text-xs text-slate-600 font-medium">Target Format:</span>
              <select
                value={targetFormat}
                onChange={(e) => setTargetFormat(e.target.value as any)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-900 focus:outline-none"
              >
                <option value="image/webp">WEBP (Recommended)</option>
                <option value="image/png">PNG (Lossless)</option>
                <option value="image/jpeg">JPEG (Compressed)</option>
              </select>
            </div>

            {/* Resize Inputs */}
            {bulkMode === 'resize' && (
              <div className="flex items-center space-x-2">
                <span className="text-xs text-slate-600 font-medium">Max Dimensions:</span>
                <input
                  type="number"
                  value={targetWidth}
                  onChange={(e) => setTargetWidth(Number(e.target.value))}
                  className="w-20 bg-slate-50 border border-slate-200 rounded px-2 py-1 text-xs text-slate-900 font-mono"
                />
                <span className="text-xs text-slate-500">×</span>
                <input
                  type="number"
                  value={targetHeight}
                  onChange={(e) => setTargetHeight(Number(e.target.value))}
                  className="w-20 bg-slate-50 border border-slate-200 rounded px-2 py-1 text-xs text-slate-900 font-mono"
                />
                <span className="text-xs text-slate-500">px</span>
              </div>
            )}

            {/* Quality Slider */}
            <div className="flex items-center space-x-2">
              <span className="text-xs text-slate-600 font-medium">Quality:</span>
              <input
                type="range"
                min="0.5"
                max="1.0"
                step="0.05"
                value={quality}
                onChange={(e) => setQuality(Number(e.target.value))}
                className="w-24 accent-blue-600 cursor-pointer"
              />
              <span className="text-xs text-slate-800 font-mono font-bold">{Math.round(quality * 100)}%</span>
            </div>
          </div>

          {/* Upload Drop Zone if empty */}
          {items.length === 0 && (
            <div className="border-2 border-dashed border-slate-300 rounded-2xl p-10 text-center space-y-3 bg-white">
              <Layers className="w-10 h-10 text-slate-400 mx-auto" />
              <h4 className="text-slate-900 text-sm font-semibold">No images added yet</h4>
              <p className="text-slate-500 text-xs">Click "Add Images" above to upload multiple files for batch processing.</p>
            </div>
          )}

          {/* Image Queue List */}
          {items.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-600 font-medium">
                <span>Queue ({items.length} files)</span>
                {isProcessing && (
                  <span className="text-blue-600 font-bold">Processing: {overallProgress}%</span>
                )}
              </div>

              {/* Progress Bar */}
              {isProcessing && (
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden border border-slate-300">
                  <div
                    className="bg-blue-600 h-full transition-all duration-300"
                    style={{ width: `${overallProgress}%` }}
                  />
                </div>
              )}

              <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white border border-slate-200 rounded-xl p-3 flex items-center justify-between gap-4 shadow-xs"
                  >
                    <div className="flex items-center space-x-3 overflow-hidden">
                      <img
                        src={item.originalUrl}
                        alt={item.name}
                        className="w-12 h-12 object-cover rounded-lg bg-slate-100 border border-slate-200 shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="text-slate-900 text-xs font-semibold truncate">{item.name}</div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {formatFileSize(item.size)}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <span className="text-xs">
                        {item.status === 'idle' && <span className="text-slate-500">Queued</span>}
                        {item.status === 'processing' && <span className="text-blue-600 font-medium animate-pulse">Processing...</span>}
                        {item.status === 'completed' && <span className="text-emerald-600 font-semibold flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5" /> Ready</span>}
                        {item.status === 'error' && <span className="text-rose-600">Failed</span>}
                      </span>

                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-slate-400 hover:text-rose-600 p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Action Buttons: Process & ZIP Export */}
              <div className="pt-4 flex flex-wrap items-center justify-between gap-4 border-t border-slate-200">
                <button
                  onClick={processBulk}
                  disabled={isProcessing}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-2.5 rounded-xl shadow-xs flex items-center space-x-2 transition-all disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isProcessing ? 'Processing Batch...' : 'Process All Images'}</span>
                </button>

                {zipBlob && (
                  <a
                    href={URL.createObjectURL(zipBlob)}
                    download="vivel-ai-processed-batch.zip"
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-2.5 rounded-xl shadow-md flex items-center space-x-2 transition-all animate-bounce"
                  >
                    <FileArchive className="w-4 h-4" />
                    <span>Download ZIP Archive</span>
                  </a>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
