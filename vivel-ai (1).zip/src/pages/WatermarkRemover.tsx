import React, { useState, useRef, useEffect, useCallback } from 'react';
import { processWatermarkRemoval, loadImage } from '../utils/imageProcessing';
import { BeforeAfterSlider } from '../components/BeforeAfterSlider';
import { SamplePicker } from '../components/SamplePicker';
import { 
  Eraser, 
  Upload, 
  Sparkles, 
  RotateCcw, 
  Paintbrush, 
  CheckCircle2, 
  Download,
  Eye,
  Sliders
} from 'lucide-react';
import type { WatermarkToolMode } from '../types';

export const WatermarkRemover: React.FC = () => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [imageName, setImageName] = useState<string>('watermark-sample.png');
  const [processedUrl, setProcessedUrl] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Canvas state for manual mask painting
  const [toolMode, setToolMode] = useState<WatermarkToolMode>('brush');
  const [brushSize, setBrushSize] = useState<number>(30);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const imageCanvasRef = useRef<HTMLCanvasElement>(null);
  const maskCanvasRef = useRef<HTMLCanvasElement>(null);
  const [canvasDimensions, setCanvasDimensions] = useState<{ width: number; height: number }>({ width: 0, height: 0 });

  // Load image onto canvas
  const setupCanvas = useCallback(async (srcUrl: string) => {
    setImageSrc(srcUrl);
    setProcessedUrl(null);

    const img = await loadImage(srcUrl);
    const w = img.naturalWidth || img.width;
    const h = img.naturalHeight || img.height;
    setCanvasDimensions({ width: w, height: h });

    setTimeout(() => {
      // Draw base image
      const imgCanvas = imageCanvasRef.current;
      if (imgCanvas) {
        imgCanvas.width = w;
        imgCanvas.height = h;
        const ctx = imgCanvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, w, h);
        }
      }

      // Initialize transparent mask canvas
      const maskCanvas = maskCanvasRef.current;
      if (maskCanvas) {
        maskCanvas.width = w;
        maskCanvas.height = h;
        const maskCtx = maskCanvas.getContext('2d');
        if (maskCtx) {
          maskCtx.clearRect(0, 0, w, h);
        }
      }
    }, 50);
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageName(file.name);
      const url = URL.createObjectURL(file);
      setupCanvas(url);
    }
  };

  // Drawing helper functions
  const getCanvasCoordinates = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = maskCanvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    let clientX = 0;
    let clientY = 0;

    if ('touches' in e) {
      if (e.touches.length > 0) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      }
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    draw(e);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    const canvas = maskCanvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) ctx.beginPath();
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = maskCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCanvasCoordinates(e);

    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (toolMode === 'brush') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.65)'; // Highlight mask color
      ctx.lineTo(x, y);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x, y);
    } else if (toolMode === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.arc(x, y, brushSize / 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
    }
  };

  const clearMask = () => {
    const maskCanvas = maskCanvasRef.current;
    if (maskCanvas) {
      const ctx = maskCanvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, maskCanvas.width, maskCanvas.height);
      }
    }
  };

  const handleProcessWatermark = async () => {
    if (!imageCanvasRef.current || !maskCanvasRef.current) return;
    setIsProcessing(true);

    try {
      const resultUrl = await processWatermarkRemoval(
        imageCanvasRef.current,
        maskCanvasRef.current
      );
      setProcessedUrl(resultUrl);
    } catch (err) {
      console.error('Watermark removal error:', err);
    } fontinally: {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 px-4 py-6">
      {/* Title */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-slate-900 flex items-center justify-center gap-2">
          <Eraser className="w-8 h-8 text-blue-600" />
          <span>Watermark Remover</span>
        </h1>
        <p className="text-slate-600 text-sm max-w-lg mx-auto">
          Highlight unwanted text, logos, or timestamps on your image and erase them cleanly.
        </p>
      </div>

      {!imageSrc ? (
        <div className="space-y-6">
          <div className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-3xl p-12 text-center bg-slate-50 transition-all">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
              id="watermark-upload"
            />
            <label htmlFor="watermark-upload" className="cursor-pointer space-y-4 inline-block">
              <div className="w-16 h-16 rounded-2xl bg-blue-100 border border-blue-200 text-blue-600 flex items-center justify-center mx-auto shadow-xs">
                <Upload className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-slate-900 font-semibold text-base mb-1">
                  Upload Image with Watermark
                </h3>
                <p className="text-slate-500 text-xs">Supports PNG, JPG, WebP formats</p>
              </div>
              <span className="inline-block bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors shadow-xs">
                Select Image
              </span>
            </label>
          </div>

          <SamplePicker
            categoryFilter="watermark"
            onSelectSample={(url, name) => {
              setImageName(name);
              setupCanvas(url);
            }}
          />
        </div>
      ) : (
        <div className="space-y-6">
          {/* Main Controls & Canvas Workspace */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-6 space-y-4">
            
            {/* Top Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
              
              <div className="flex items-center space-x-2">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider mr-2">Selection Tool:</span>
                
                <button
                  onClick={() => setToolMode('brush')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
                    toolMode === 'brush'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Paintbrush className="w-3.5 h-3.5" />
                  <span>Highlight Area</span>
                </button>

                <button
                  onClick={() => setToolMode('eraser')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
                    toolMode === 'eraser'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Eraser className="w-3.5 h-3.5" />
                  <span>Erase Mask</span>
                </button>

                <button
                  onClick={clearMask}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 bg-white border border-slate-200 hover:bg-slate-100 hover:text-rose-600 flex items-center space-x-1 transition-all"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Clear All</span>
                </button>
              </div>

              {/* Brush Size Slider */}
              <div className="flex items-center space-x-3 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
                <span className="text-xs text-slate-600 font-medium">Brush Size:</span>
                <input
                  type="range"
                  min="5"
                  max="100"
                  value={brushSize}
                  onChange={(e) => setBrushSize(Number(e.target.value))}
                  className="w-24 accent-blue-600 cursor-pointer"
                />
                <span className="text-xs text-slate-900 font-mono font-bold w-6">{brushSize}px</span>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setImageSrc(null)}
                  className="text-xs text-slate-600 hover:text-slate-900 px-3 py-1.5"
                >
                  Change Image
                </button>
                <button
                  onClick={handleProcessWatermark}
                  disabled={isProcessing}
                  className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-5 py-2 rounded-xl shadow-xs flex items-center space-x-2 transition-all disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isProcessing ? 'Removing Watermark...' : 'Erase Watermark Now'}</span>
                </button>
              </div>
            </div>

            {/* Instruction Banner */}
            <div className="bg-blue-50/80 border border-blue-200 rounded-xl p-3 text-xs text-blue-800 flex items-center justify-between">
              <span className="flex items-center space-x-2 font-medium">
                <Paintbrush className="w-4 h-4 text-blue-600" />
                <span>Paint over the watermark or logo with your mouse or touch screen, then click <strong>Erase Watermark Now</strong>.</span>
              </span>
            </div>

            {/* Canvas Interactive Editor */}
            <div
              ref={containerRef}
              className="relative overflow-hidden rounded-xl border border-slate-300 bg-checkerboard flex items-center justify-center max-h-[550px]"
            >
              <canvas
                ref={imageCanvasRef}
                className="max-w-full max-h-[500px] object-contain block"
              />
              <canvas
                ref={maskCanvasRef}
                onMouseDown={startDrawing}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onMouseMove={draw}
                onTouchStart={startDrawing}
                onTouchEnd={stopDrawing}
                onTouchMove={draw}
                className="absolute top-0 left-0 w-full h-full object-contain cursor-crosshair touch-none"
              />
            </div>
          </div>

          {/* Processed Result Comparison */}
          {processedUrl && (
            <div className="space-y-4">
              <BeforeAfterSlider
                originalUrl={imageSrc}
                processedUrl={processedUrl}
                downloadFilename={`clean-${imageName}`}
                title="Watermark Removal Comparison"
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
};
