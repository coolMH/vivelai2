import React, { useState } from 'react';
import { PageId } from '../types';
import { 
  Eraser, 
  Scissors, 
  Scaling, 
  SlidersHorizontal, 
  Layers, 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  Zap, 
  ShieldCheck, 
  Download, 
  ChevronDown, 
  ChevronUp,
  Image as ImageIcon
} from 'lucide-react';

interface HomeProps {
  onNavigate: (page: PageId) => void;
}

export const Home: React.FC<HomeProps> = ({ onNavigate }) => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const tools = [
    {
      id: 'watermark-remover' as PageId,
      name: 'Watermark Remover',
      tagline: 'Erase unwanted logos, dates, text, and overlays automatically.',
      description: 'Select unwanted objects or text and let AI seamlessly reconstruct the background texture with pristine clarity.',
      icon: <Eraser className="w-6 h-6 text-blue-600" />,
      badge: 'Popular',
    },
    {
      id: 'background-remover' as PageId,
      name: 'Background Remover',
      tagline: 'Isolate subjects with precision edge detection.',
      description: 'Instantly cut out portraits, products, and graphics. Export transparent PNGs or replace backgrounds with custom colors.',
      icon: <Scissors className="w-6 h-6 text-blue-600" />,
      badge: 'Automated',
    },
    {
      id: 'image-resizer' as PageId,
      name: 'Image Resizer',
      tagline: 'Resize, crop, and reformat without quality loss.',
      description: 'Convert image dimensions for social media formats (Instagram, YouTube, Twitter) while maintaining aspect ratio and sharpness.',
      icon: <Scaling className="w-6 h-6 text-blue-600" />,
    },
    {
      id: 'image-enhancer' as PageId,
      name: 'Image Enhancer',
      tagline: 'Sharpen details, restore contrast, and boost color vibrancy.',
      description: 'Intelligent tone mapping and sharpness adjustments elevate flat photos into crisp, professional visual assets.',
      icon: <SlidersHorizontal className="w-6 h-6 text-blue-600" />,
    },
    {
      id: 'bulk-tools' as PageId,
      name: 'Bulk Batch Tools',
      tagline: 'Process dozens of images simultaneously in seconds.',
      description: 'Resize, convert formats, and optimize collections of images in a single workflow and download as a compressed ZIP file.',
      icon: <Layers className="w-6 h-6 text-blue-600" />,
      badge: 'High Speed',
    },
  ];

  const steps = [
    {
      number: '01',
      title: 'Upload Your Image',
      description: 'Drag & drop or select photos in high resolution (PNG, JPG, WebP).',
    },
    {
      number: '02',
      title: 'AI Automated Processing',
      description: 'Our intelligent visual algorithms automatically remove backgrounds, erase watermarks, or enhance details.',
    },
    {
      number: '03',
      title: 'Download High-Res Result',
      description: 'Preview before/after results instantly and export your high-resolution image or bulk ZIP archive.',
    },
  ];

  const features = [
    {
      title: 'AI Watermark Eraser',
      description: 'Intelligently reconstruct background patterns when removing text, logos, or timestamp overlays.',
      icon: <Eraser className="w-5 h-5 text-blue-600" />,
    },
    {
      title: 'Hair-Level Cutout Precision',
      description: 'Automated subject segmentation detects subtle edges, hair strands, and complex object boundaries.',
      icon: <Scissors className="w-5 h-5 text-blue-600" />,
    },
    {
      title: 'Preset Dimension Scaling',
      description: 'One-click preset sizes for Instagram posts, YouTube thumbnails, passport photos, and custom HD resolutions.',
      icon: <Scaling className="w-5 h-5 text-blue-600" />,
    },
    {
      title: 'Detail & Color Enhancement',
      description: 'Boost clarity, reduce noise, and refine color balance with professional-grade enhancement filters.',
      icon: <SlidersHorizontal className="w-5 h-5 text-blue-600" />,
    },
    {
      title: 'High-Volume Batch Processing',
      description: 'Save hours by converting, resizing, and enhancing entire folders of images in a unified batch pipeline.',
      icon: <Layers className="w-5 h-5 text-blue-600" />,
    },
    {
      title: 'Privacy & Security Guaranteed',
      description: 'Your photos remain confidential and secure throughout every editing process.',
      icon: <ShieldCheck className="w-5 h-5 text-blue-600" />,
    },
  ];

  const faqs = [
    {
      q: 'What image formats are supported?',
      a: 'Vivel AI supports all major image formats including PNG, JPEG, JPG, WebP, and SVG output options.',
    },
    {
      q: 'Does Vivel AI compress or degrade my image quality?',
      a: 'No. Vivel AI preserves maximum output quality. You can customize quality settings and resolution output up to 100% loss-free PNG or WebP files.',
    },
    {
      q: 'How does Bulk Processing work?',
      a: 'In the Bulk Tools section, you can select multiple images at once. Apply resize dimensions, format conversions, or color enhancements across all items simultaneously and download them packaged in a ZIP archive.',
    },
    {
      q: 'Are my uploaded images kept secure and private?',
      a: 'Yes, absolutely. We prioritize your confidentiality. Your images are handled securely and are never shared or stored on external public databases.',
    },
    {
      q: 'Can I use Vivel AI for commercial projects?',
      a: 'Yes! All images processed through Vivel AI can be used freely for personal, commercial, marketing, and e-commerce applications.',
    },
  ];

  return (
    <div className="space-y-20 py-8 px-4 max-w-7xl mx-auto">
      
      {/* Hero Section */}
      <section className="text-center space-y-8 pt-6 pb-4">
        <div className="inline-flex items-center space-x-2 bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold px-4 py-1.5 rounded-full shadow-xs">
          <Sparkles className="w-3.5 h-3.5 text-blue-600" />
          <span>Next-Generation Image Editing Suite</span>
        </div>

        <div className="space-y-4 max-w-4xl mx-auto">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-tight">
            AI Image Editing <span className="text-blue-600">Made Simple</span>
          </h1>
          <p className="text-slate-600 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
            Effortlessly erase watermarks, isolate backgrounds, resize dimensions, and enhance image clarity in seconds with high-precision AI tools.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
          <button
            onClick={() => onNavigate('watermark-remover')}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm px-6 py-3.5 rounded-xl shadow-md hover:shadow-lg transition-all flex items-center space-x-2"
          >
            <span>Try Watermark Remover</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              const el = document.getElementById('tools-grid');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-sm px-6 py-3.5 rounded-xl border border-slate-200 transition-all"
          >
            Explore All Tools
          </button>
        </div>

        {/* Quick Highlights */}
        <div className="pt-6 flex flex-wrap justify-center items-center gap-6 text-xs font-medium text-slate-500">
          <span className="flex items-center space-x-1.5">
            <CheckCircle2 className="w-4 h-4 text-blue-600" />
            <span>High-Precision AI Models</span>
          </span>
          <span className="flex items-center space-x-1.5">
            <CheckCircle2 className="w-4 h-4 text-blue-600" />
            <span>High-Res Export</span>
          </span>
          <span className="flex items-center space-x-1.5">
            <CheckCircle2 className="w-4 h-4 text-blue-600" />
            <span>Batch Processing Supported</span>
          </span>
        </div>
      </section>

      {/* Tool Cards Grid */}
      <section id="tools-grid" className="space-y-8 scroll-mt-24">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Complete AI Editing Toolkit
          </h2>
          <p className="text-slate-600 text-sm max-w-lg mx-auto">
            Everything you need to produce stunning visual content for websites, social media, and products.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tools.map((tool) => (
            <div
              key={tool.id}
              onClick={() => onNavigate(tool.id)}
              className="group bg-slate-50 border border-slate-200 rounded-2xl p-6 hover:bg-white hover:border-blue-500 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between space-y-6"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-blue-100/80 border border-blue-200 flex items-center justify-center group-hover:scale-105 transition-transform">
                    {tool.icon}
                  </div>
                  {tool.badge && (
                    <span className="text-[11px] font-bold uppercase tracking-wider bg-blue-100 text-blue-700 px-2.5 py-0.5 rounded-full border border-blue-200">
                      {tool.badge}
                    </span>
                  )}
                </div>

                <div>
                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors mb-1">
                    {tool.name}
                  </h3>
                  <p className="text-xs font-semibold text-blue-600 mb-2">
                    {tool.tagline}
                  </p>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {tool.description}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-1.5 text-xs font-bold text-blue-600 group-hover:text-blue-700 pt-2 border-t border-slate-200/60">
                <span>Open Tool</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-slate-50 border border-slate-200 rounded-3xl p-8 sm:p-12 space-y-10">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            How Vivel AI Works
          </h2>
          <p className="text-slate-600 text-sm max-w-md mx-auto">
            Transform your photos in three simple steps.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, idx) => (
            <div key={idx} className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs relative">
              <span className="text-3xl font-extrabold text-blue-600 font-mono">
                {step.number}
              </span>
              <h3 className="text-base font-bold text-slate-900">
                {step.title}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Professional Features Grid */}
      <section className="space-y-10">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Built for Commercial Speed & Precision
          </h2>
          <p className="text-slate-600 text-sm max-w-lg mx-auto">
            Designed to empower creators, marketers, e-commerce stores, and photographers.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat, idx) => (
            <div key={idx} className="bg-white border border-slate-200 rounded-2xl p-6 space-y-3 shadow-xs">
              <div className="w-10 h-10 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center">
                {feat.icon}
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                {feat.title}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {feat.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="text-slate-600 text-sm">
            Everything you need to know about Vivel AI.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="bg-slate-50 border border-slate-200 rounded-2xl overflow-hidden transition-all"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full text-left p-5 font-semibold text-slate-900 text-sm flex items-center justify-between gap-4 focus:outline-none"
                >
                  <span>{faq.q}</span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-blue-600 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs text-slate-600 leading-relaxed border-t border-slate-200/60">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

    </div>
  );
};
