export type PageId = 
  | 'home' 
  | 'watermark-remover' 
  | 'background-remover' 
  | 'image-resizer' 
  | 'image-enhancer' 
  | 'bulk-tools' 
  | 'contact';

export interface ProcessedImage {
  id: string;
  file: File;
  originalUrl: string;
  processedUrl?: string;
  name: string;
  size: number;
  type: string;
  dimensions?: { width: number; height: number };
  processedSize?: number;
  status: 'idle' | 'processing' | 'completed' | 'error';
  error?: string;
  progress?: number;
}

export interface SampleImage {
  id: string;
  name: string;
  category: 'watermark' | 'portrait' | 'landscape' | 'general';
  url: string;
  description: string;
}

export interface EnhancementSettings {
  brightness: number; // -100 to 100
  contrast: number; // -100 to 100
  saturation: number; // -100 to 100
  sharpness: number; // 0 to 100
  temperature: number; // -100 to 100
  blur: number; // 0 to 20
  vibrance: number; // -100 to 100
  vintage: number; // 0 to 100
}

export interface ResizeSettings {
  width: number;
  height: number;
  maintainAspectRatio: boolean;
  unit: 'px' | 'percentage';
  percentage: number;
  format: 'image/png' | 'image/jpeg' | 'image/webp';
  quality: number; // 0.1 to 1.0
  scaleMode: 'fit' | 'fill' | 'stretch';
}

export interface BackgroundRemoverSettings {
  bgType: 'transparent' | 'color' | 'blur' | 'custom-image';
  color: string;
  blurAmount: number;
  customBgUrl?: string;
  edgeSmoothing: number;
}
