import React, { useState } from 'react';
import { PageId } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { WatermarkRemover } from './pages/WatermarkRemover';
import { BackgroundRemover } from './pages/BackgroundRemover';
import { ImageResizer } from './pages/ImageResizer';
import { ImageEnhancer } from './pages/ImageEnhancer';
import { BulkTools } from './pages/BulkTools';
import { Contact } from './pages/Contact';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [activePage, setActivePage] = useState<PageId>('home');

  const handleNavigate = (page: PageId) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderPage = () => {
    switch (activePage) {
      case 'home':
        return <Home onNavigate={handleNavigate} />;
      case 'watermark-remover':
        return <WatermarkRemover />;
      case 'background-remover':
        return <BackgroundRemover />;
      case 'image-resizer':
        return <ImageResizer />;
      case 'image-enhancer':
        return <ImageEnhancer />;
      case 'bulk-tools':
        return <BulkTools />;
      case 'contact':
        return <Contact />;
      default:
        return <Home onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900 font-sans selection:bg-blue-100 selection:text-blue-900">
      {/* Navigation Header */}
      <Header activePage={activePage} onNavigate={handleNavigate} />

      {/* Main Content Area */}
      <main className="flex-1 py-6 px-2 sm:px-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={activePage}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
