// Utility to generate rich canvas data URLs for quick sample image testing

export interface PredefinedSample {
  id: string;
  name: string;
  category: string;
  description: string;
  dataUrl: string;
}

export function generateSampleImages(): PredefinedSample[] {
  // 1. Watermark Sample: Photo with a watermark text & logo overlay
  const wmCanvas = document.createElement('canvas');
  wmCanvas.width = 1000;
  wmCanvas.height = 700;
  const ctx = wmCanvas.getContext('2d')!;

  // Sunset background
  const grad = ctx.createLinearGradient(0, 0, 1000, 700);
  grad.addColorStop(0, '#fdba74');
  grad.addColorStop(0.5, '#f43f5e');
  grad.addColorStop(1, '#6366f1');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 1000, 700);

  // Mountains silhouetted
  ctx.fillStyle = '#1e1b4b';
  ctx.beginPath();
  ctx.moveTo(0, 700);
  ctx.lineTo(250, 450);
  ctx.lineTo(450, 580);
  ctx.lineTo(700, 380);
  ctx.lineTo(1000, 700);
  ctx.closePath();
  ctx.fill();

  // Sun
  ctx.fillStyle = '#fef08a';
  ctx.beginPath();
  ctx.arc(700, 260, 60, 0, Math.PI * 2);
  ctx.fill();

  // Watermark Text Overlay across center
  ctx.save();
  ctx.translate(500, 350);
  ctx.rotate(-Math.PI / 8);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.3)';
  ctx.lineWidth = 2;
  ctx.font = 'bold 52px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('SAMPLE WATERMARK', 0, 0);
  ctx.strokeText('SAMPLE WATERMARK', 0, 0);
  ctx.font = '24px sans-serif';
  ctx.fillText('© PROOF COPY DO NOT DISTRIBUTE', 0, 45);
  ctx.restore();

  // Stamp in corner
  ctx.fillStyle = 'rgba(239, 68, 68, 0.6)';
  ctx.beginPath();
  ctx.arc(880, 120, 55, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 16px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('WATERMARK', 880, 125);

  const watermarkDataUrl = wmCanvas.toDataURL('image/png');

  // 2. Portrait / Subject Sample for Background Removal
  const bgCanvas = document.createElement('canvas');
  bgCanvas.width = 900;
  bgCanvas.height = 900;
  const ctx2 = bgCanvas.getContext('2d')!;

  // Green studio screen background for crisp demo
  ctx2.fillStyle = '#22c55e';
  ctx2.fillRect(0, 0, 900, 900);

  // Modern abstract product / geometric camera avatar
  ctx2.fillStyle = '#3b82f6';
  ctx2.beginPath();
  ctx2.arc(450, 380, 180, 0, Math.PI * 2);
  ctx2.fill();

  // Eyes / Lens details
  ctx2.fillStyle = '#ffffff';
  ctx2.beginPath();
  ctx2.arc(450, 380, 120, 0, Math.PI * 2);
  ctx2.fill();
  ctx2.fillStyle = '#0f172a';
  ctx2.beginPath();
  ctx2.arc(450, 380, 70, 0, Math.PI * 2);
  ctx2.fill();
  ctx2.fillStyle = '#38bdf8';
  ctx2.beginPath();
  ctx2.arc(480, 350, 25, 0, Math.PI * 2);
  ctx2.fill();

  // Body / Pedestal
  ctx2.fillStyle = '#1e293b';
  ctx2.beginPath();
  ctx2.roundRect(250, 580, 400, 260, 40);
  ctx2.fill();

  // Badge label
  ctx2.fillStyle = '#f59e0b';
  ctx2.beginPath();
  ctx2.arc(450, 680, 45, 0, Math.PI * 2);
  ctx2.fill();
  ctx2.fillStyle = '#ffffff';
  ctx2.font = 'bold 36px sans-serif';
  ctx2.textAlign = 'center';
  ctx2.fillText('★', 450, 692);

  const portraitDataUrl = bgCanvas.toDataURL('image/png');

  // 3. Landscape / Photo for Enhancement & Resizing
  const landCanvas = document.createElement('canvas');
  landCanvas.width = 1200;
  landCanvas.height = 800;
  const ctx3 = landCanvas.getContext('2d')!;

  // Sky gradient
  const skyGrad = ctx3.createLinearGradient(0, 0, 0, 500);
  skyGrad.addColorStop(0, '#0284c7');
  skyGrad.addColorStop(1, '#bae6fd');
  ctx3.fillStyle = skyGrad;
  ctx3.fillRect(0, 0, 1200, 500);

  // Ocean
  const seaGrad = ctx3.createLinearGradient(0, 500, 0, 800);
  seaGrad.addColorStop(0, '#0369a1');
  seaGrad.addColorStop(1, '#0c4a6e');
  ctx3.fillStyle = seaGrad;
  ctx3.fillRect(0, 500, 1200, 300);

  // Island
  ctx3.fillStyle = '#15803d';
  ctx3.beginPath();
  ctx3.ellipse(400, 520, 220, 70, 0, 0, Math.PI * 2);
  ctx3.fill();

  // Palm tree
  ctx3.strokeStyle = '#78350f';
  ctx3.lineWidth = 16;
  ctx3.beginPath();
  ctx3.moveTo(400, 520);
  ctx3.quadraticCurveTo(420, 400, 460, 300);
  ctx3.stroke();

  // Palm leaves
  ctx3.fillStyle = '#16a34a';
  for (let i = 0; i < 6; i++) {
    const angle = (i * Math.PI) / 3;
    ctx3.beginPath();
    ctx3.ellipse(460 + Math.cos(angle) * 40, 300 + Math.sin(angle) * 30, 70, 20, angle, 0, Math.PI * 2);
    ctx3.fill();
  }

  // Sun
  ctx3.fillStyle = '#fde047';
  ctx3.beginPath();
  ctx3.arc(1000, 150, 70, 0, Math.PI * 2);
  ctx3.fill();

  const landscapeDataUrl = landCanvas.toDataURL('image/png');

  return [
    {
      id: 'sample-watermark',
      name: 'Watermarked Landscape',
      category: 'watermark',
      description: 'Photo with watermark text and overlay stamp for testing erasure.',
      dataUrl: watermarkDataUrl,
    },
    {
      id: 'sample-portrait',
      name: 'Studio Product Subject',
      category: 'portrait',
      description: 'Clear subject on green studio background ideal for background removal.',
      dataUrl: portraitDataUrl,
    },
    {
      id: 'sample-landscape',
      name: 'Tropical Coastal Scene',
      category: 'landscape',
      description: 'High dynamic range image ideal for resizing, enhancement & bulk tools.',
      dataUrl: landscapeDataUrl,
    },
  ];
}
