import React, { useState, useEffect } from 'react';
import { generateSampleImages, PredefinedSample } from '../utils/sampleImages';
import { Sparkles } from 'lucide-react';

interface SamplePickerProps {
  onSelectSample: (dataUrl: string, name: string) => void;
  categoryFilter?: 'watermark' | 'portrait' | 'landscape' | 'general';
}

export const SamplePicker: React.FC<SamplePickerProps> = ({ onSelectSample, categoryFilter }) => {
  const [samples, setSamples] = useState<PredefinedSample[]>([]);

  useEffect(() => {
    const list = generateSampleImages();
    if (categoryFilter) {
      setSamples(list.filter((s) => s.category === categoryFilter || s.category === 'general'));
    } else {
      setSamples(list);
    }
  }, [categoryFilter]);

  return (
    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2 text-blue-600 text-xs font-semibold uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Or Try A Demo Sample Image</span>
        </div>
        <span className="text-[11px] text-slate-500">Click to load instantly</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {samples.map((sample) => (
          <button
            key={sample.id}
            onClick={() => onSelectSample(sample.dataUrl, sample.name)}
            className="group relative bg-white border border-slate-200 rounded-lg p-2 text-left hover:border-blue-500 hover:bg-slate-50 transition-all flex items-center space-x-3 overflow-hidden focus:outline-none shadow-xs"
          >
            <div className="w-14 h-14 rounded-md overflow-hidden bg-slate-100 shrink-0 border border-slate-200">
              <img
                src={sample.dataUrl}
                alt={sample.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
            </div>
            <div className="min-w-0 flex-1">
              <h4 className="text-slate-900 text-xs font-semibold truncate group-hover:text-blue-600 transition-colors">
                {sample.name}
              </h4>
              <p className="text-[11px] text-slate-500 line-clamp-2 leading-tight mt-0.5">
                {sample.description}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
