import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white text-slate-500 border-t border-slate-200 mt-auto py-8 text-center text-sm font-medium">
      <div className="max-w-7xl mx-auto px-4">
        <p>© 2026 Vivel AI. All rights reserved.</p>
      </div>
    </footer>
  );
};
