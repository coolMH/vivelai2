import React, { useState, useRef, useCallback } from 'react';
import { Columns, SplitSquareVertical, Download, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';

interface BeforeAfterSliderProps {
  originalUrl: string;
  processedUrl: string;
  onDownload?: () => void;
  downloadFilename?: string;
  title?: string;
}

export const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({
  originalUrl,
  processedUrl,
  onDownload,
  downloadFilename = 'vivel-ai-output.png',
  title = 'Interactive Comparison',
}) => {
  const [sliderPos, setSliderPos] = useState<number>(50); // percentage 0 - 100
  const [viewMode, setViewMode] = useState<'slider' | 'side-by-side'>('slider');
  const [zoom, setZoom] = useState<number>(1);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef<boolean>(false);

  const handleMove = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    let percentage = (x / rect.width) * 100;
    if (percentage < 0) percentage = 0;
    if (percentage > 100) percentage = 100;
    setSliderPos(percentage);
  }, []);

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length > 0) {
      handleMove(e.touches[0].clientX);
    }
  };

  const handleMouseDown = () => {
    isDragging.current = true;
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging.current) {
      handleMove(e.clientX);
    }
  };

  return (
    <div className="bg-slate-50 border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
      {/* Controls Bar */}
      <div className="bg-white px-4 py-3 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-2">
          <span className="text-slate-900 font-semibold text-sm">{title}</span>
        </div>

        <div className="flex items-center space-x-2 text-xs">
          {/* View Mode Toggle */}
          <div className="bg-slate-100 p-1 rounded-lg border border-slate-200 flex items-center space-x-1">
            <button
              onClick={() => setViewMode('slider')}
              className={`px-2.5 py-1 rounded flex items-center space-x-1 font-medium transition-colors ${
                viewMode === 'slider' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <SplitSquareVertical className="w-3.5 h-3.5" />
              <span>Split Slider</span>
            </button>
            <button
              onClick={() => setViewMode('side-by-side')}
              className={`px-2.5 py-1 rounded flex items-center space-x-1 font-medium transition-colors ${
                viewMode === 'side-by-side' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Columns className="w-3.5 h-3.5" />
              <span>Side-by-Side</span>
            </button>
          </div>

          {/* Zoom Buttons */}
          <div className="bg-slate-100 p-1 rounded-lg border border-slate-200 flex items-center space-x-1">
            <button
              onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}
              className="p-1 text-slate-600 hover:text-slate-900 transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-slate-800 font-mono px-1 font-semibold">{Math.round(zoom * 100)}%</span>
            <button
              onClick={() => setZoom((z) => Math.min(3, z + 0.25))}
              className="p-1 text-slate-600 hover:text-slate-900 transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            {zoom !== 1 && (
              <button
                onClick={() => setZoom(1)}
                className="p-1 text-slate-600 hover:text-slate-900 transition-colors"
                title="Reset Zoom"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Download Button */}
          {onDownload ? (
            <button
              onClick={onDownload}
              className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-3.5 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Result</span>
            </button>
          ) : (
            <a
              href={processedUrl}
              download={downloadFilename}
              className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-3.5 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Result</span>
            </a>
          )}
        </div>
      </div>

      {/* Comparison Area */}
      <div className="p-4 bg-slate-100/60 overflow-auto max-h-[600px] flex justify-center items-center">
        {viewMode === 'slider' ? (
          <div
            ref={containerRef}
            onMouseDown={handleMouseDown}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onMouseMove={handleMouseMove}
            onTouchMove={handleTouchMove}
            className="relative select-none cursor-ew-resize overflow-hidden rounded-xl border border-slate-300 bg-checkerboard"
            style={{
              transform: `scale(${zoom})`,
              transformOrigin: 'center center',
              transition: isDragging.current ? 'none' : 'transform 0.2s ease',
            }}
          >
            {/* Processed (After) Image - Background */}
            <img
              src={processedUrl}
              alt="Processed Result"
              className="block max-w-full max-h-[500px] object-contain pointer-events-none"
            />

            {/* Original (Before) Image - Clipped Overlay */}
            <div
              className="absolute top-0 left-0 bottom-0 overflow-hidden pointer-events-none"
              style={{ width: `${sliderPos}%` }}
            >
              <img
                src={originalUrl}
                alt="Original Source"
                className="block max-w-none max-h-[500px] object-contain"
                style={{
                  width: containerRef.current ? containerRef.current.clientWidth : '100%',
                  height: '100%',
                }}
              />
            </div>

            {/* Split Drag Line & Knob */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-blue-600 shadow-[0_0_10px_rgba(37,99,235,0.5)] pointer-events-none"
              style={{ left: `${sliderPos}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-md border border-white font-bold text-xs">
                ↔
              </div>
            </div>

            {/* Labels */}
            <span className="absolute top-3 left-3 bg-slate-900/80 text-white text-xs font-medium px-2.5 py-1 rounded backdrop-blur border border-slate-700 pointer-events-none">
              Original (Before)
            </span>
            <span className="absolute top-3 right-3 bg-blue-600/90 text-white text-xs font-medium px-2.5 py-1 rounded backdrop-blur border border-blue-500 pointer-events-none">
              Processed (After)
            </span>
          </div>
        ) : (
          /* Side-by-Side View */
          <div
            className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full"
            style={{
              transform: `scale(${zoom})`,
              transformOrigin: 'top center',
            }}
          >
            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-600 block uppercase tracking-wider">Original</span>
              <div className="bg-white p-2 rounded-xl border border-slate-200 flex justify-center items-center">
                <img src={originalUrl} alt="Original" className="max-h-[400px] object-contain rounded-lg" />
              </div>
            </div>
            <div className="space-y-2">
              <span className="text-xs font-semibold text-blue-600 block uppercase tracking-wider">Processed Result</span>
              <div className="bg-white p-2 rounded-xl border border-slate-200 flex justify-center items-center">
                <img src={processedUrl} alt="Processed" className="max-h-[400px] object-contain rounded-lg" />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
