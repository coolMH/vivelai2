/**
 * Vivel AI - Core Image Processing Utility Library
 */

/**
 * Loads an image source URL into an HTMLImageElement
 */
function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(new Error('Failed to load image: ' + err));
    img.src = src;
  });
}

/**
 * Converts a dataURL string to a Blob object
 */
function dataURLtoBlob(dataurl) {
  const arr = dataurl.split(',');
  const mimeMatch = arr[0].match(/:(.*?);/);
  const mime = mimeMatch ? mimeMatch[1] : 'image/png';
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], { type: mime });
}

/**
 * Watermark Removal via Fast Inpainting Algorithm
 * Replaces marked pixels with spatial interpolation from nearest non-masked boundary pixels.
 */
async function processWatermarkRemoval(imgSource, maskCanvas) {
  const width = imgSource.naturalWidth || imgSource.width;
  const height = imgSource.naturalHeight || imgSource.height;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });

  // Draw source image
  ctx.drawImage(imgSource, 0, 0, width, height);
  const imgData = ctx.getImageData(0, 0, width, height);
  const pixels = imgData.data;

  // Scale mask canvas to match natural width/height if needed
  const tempMaskCanvas = document.createElement('canvas');
  tempMaskCanvas.width = width;
  tempMaskCanvas.height = height;
  const tempMaskCtx = tempMaskCanvas.getContext('2d', { willReadFrequently: true });
  tempMaskCtx.drawImage(maskCanvas, 0, 0, width, height);
  const maskData = tempMaskCtx.getImageData(0, 0, width, height).data;

  // Identify mask pixels
  const isMasked = new Uint8Array(width * height);
  let maskedCount = 0;

  for (let i = 0; i < width * height; i++) {
    const alpha = maskData[i * 4 + 3];
    const r = maskData[i * 4];
    if (alpha > 30 || r > 100) {
      isMasked[i] = 1;
      maskedCount++;
    }
  }

  if (maskedCount === 0) {
    return canvas.toDataURL('image/png');
  }

  // Multi-pass boundary propagation inpainting
  const maxPasses = 16;
  let remainingMasked = maskedCount;

  for (let pass = 0; pass < maxPasses && remainingMasked > 0; pass++) {
    const nextMasked = new Uint8Array(isMasked);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = y * width + x;
        if (isMasked[idx] === 0) continue;

        let rSum = 0, gSum = 0, bSum = 0, aSum = 0;
        let weightSum = 0;

        const radius = 2 + Math.floor(pass / 3);

        for (let dy = -radius; dy <= radius; dy++) {
          const ny = y + dy;
          if (ny < 0 || ny >= height) continue;

          for (let dx = -radius; dx <= radius; dx++) {
            const nx = x + dx;
            if (nx < 0 || nx >= width) continue;

            const nidx = ny * width + nx;
            if (isMasked[nidx] === 0) {
              const dist = Math.sqrt(dx * dx + dy * dy);
              const weight = 1 / (dist + 0.5);

              const p = nidx * 4;
              rSum += pixels[p] * weight;
              gSum += pixels[p + 1] * weight;
              bSum += pixels[p + 2] * weight;
              aSum += pixels[p + 3] * weight;
              weightSum += weight;
            }
          }
        }

        if (weightSum > 0) {
          const p = idx * 4;
          pixels[p] = Math.min(255, Math.max(0, Math.round(rSum / weightSum)));
          pixels[p + 1] = Math.min(255, Math.max(0, Math.round(gSum / weightSum)));
          pixels[p + 2] = Math.min(255, Math.max(0, Math.round(bSum / weightSum)));
          pixels[p + 3] = Math.min(255, Math.max(0, Math.round(aSum / weightSum)));

          nextMasked[idx] = 0;
          remainingMasked--;
        }
      }
    }

    isMasked.set(nextMasked);
  }

  ctx.putImageData(imgData, 0, 0);
  return canvas.toDataURL('image/png');
}

/**
 * Remove Background using Edge-Gradient & Corner Color Floodfill
 */
async function processBackgroundRemoval(imageSrc) {
  const img = await loadImage(imageSrc);
  const width = img.naturalWidth || img.width;
  const height = img.naturalHeight || img.height;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });

  ctx.drawImage(img, 0, 0, width, height);
  const imgData = ctx.getImageData(0, 0, width, height);
  const pixels = imgData.data;

  // Sample corner background colors
  const sampleIndices = [
    0,
    (width - 1) * 4,
    (height - 1) * width * 4,
    ((height - 1) * width + (width - 1)) * 4
  ];

  const bgColors = sampleIndices.map((idx) => ({
    r: pixels[idx],
    g: pixels[idx + 1],
    b: pixels[idx + 2],
  }));

  const tolerance = 48;

  for (let i = 0; i < width * height; i++) {
    const p = i * 4;
    const r = pixels[p];
    const g = pixels[p + 1];
    const b = pixels[p + 2];

    let isBg = false;
    for (const bg of bgColors) {
      const dist = Math.sqrt(
        (r - bg.r) ** 2 +
        (g - bg.g) ** 2 +
        (b - bg.b) ** 2
      );
      if (dist < tolerance) {
        isBg = true;
        break;
      }
    }

    if (isBg) {
      pixels[p + 3] = 0;
    }
  }

  ctx.putImageData(imgData, 0, 0);
  return canvas.toDataURL('image/png');
}

/**
 * Image Resizer
 */
async function processImageResize(img, settings) {
  let targetWidth = settings.width;
  let targetHeight = settings.height;

  if (settings.unit === 'percentage') {
    const factor = settings.percentage / 100;
    targetWidth = Math.max(1, Math.round(img.naturalWidth * factor));
    targetHeight = Math.max(1, Math.round(img.naturalHeight * factor));
  }

  const canvas = document.createElement('canvas');
  canvas.width = targetWidth;
  canvas.height = targetHeight;
  const ctx = canvas.getContext('2d');

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  if (settings.scaleMode === 'stretch') {
    ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
  } else if (settings.scaleMode === 'fit') {
    const aspectImg = img.naturalWidth / img.naturalHeight;
    const aspectCanvas = targetWidth / targetHeight;

    let drawWidth = targetWidth;
    let drawHeight = targetHeight;
    let offsetX = 0;
    let offsetY = 0;

    if (aspectImg > aspectCanvas) {
      drawHeight = targetWidth / aspectImg;
      offsetY = (targetHeight - drawHeight) / 2;
    } else {
      drawWidth = targetHeight * aspectImg;
      offsetX = (targetWidth - drawWidth) / 2;
    }
    ctx.drawImage(img, offsetX, offsetY, drawWidth, drawHeight);
  } else {
    // Fill mode (crop fit)
    const aspectImg = img.naturalWidth / img.naturalHeight;
    const aspectCanvas = targetWidth / targetHeight;

    let srcWidth = img.naturalWidth;
    let srcHeight = img.naturalHeight;
    let srcX = 0;
    let srcY = 0;

    if (aspectImg > aspectCanvas) {
      srcWidth = img.naturalHeight * aspectCanvas;
      srcX = (img.naturalWidth - srcWidth) / 2;
    } else {
      srcHeight = img.naturalWidth / aspectCanvas;
      srcY = (img.naturalHeight - srcHeight) / 2;
    }
    ctx.drawImage(img, srcX, srcY, srcWidth, srcHeight, 0, 0, targetWidth, targetHeight);
  }

  const format = settings.format || 'image/png';
  const dataUrl = canvas.toDataURL(format, settings.quality || 0.92);
  const blob = dataURLtoBlob(dataUrl);

  return { dataUrl, width: targetWidth, height: targetHeight, blob };
}

/**
 * Image Enhancer with CSS & Convolution Matrix Filters
 */
async function processImageEnhancement(img, settings) {
  const width = img.naturalWidth || img.width;
  const height = img.naturalHeight || img.height;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });

  const bVal = 100 + (settings.brightness || 0);
  const cVal = 100 + (settings.contrast || 0);
  const sVal = 100 + (settings.saturation || 0);
  const blurVal = (settings.blur || 0) > 0 ? `${settings.blur}px` : '0px';

  ctx.filter = `brightness(${bVal}%) contrast(${cVal}%) saturate(${sVal}%) blur(${blurVal})`;
  ctx.drawImage(img, 0, 0, width, height);

  if ((settings.sharpness || 0) > 0) {
    const sharpFactor = settings.sharpness / 100;
    const imgData = ctx.getImageData(0, 0, width, height);
    const pixels = imgData.data;
    const copy = new Uint8ClampedArray(pixels);

    const k = sharpFactor * 0.8;
    const centerWeight = 1 + 4 * k;

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4;

        const top = ((y - 1) * width + x) * 4;
        const bottom = ((y + 1) * width + x) * 4;
        const left = (y * width + (x - 1)) * 4;
        const right = (y * width + (x + 1)) * 4;

        for (let c = 0; c < 3; c++) {
          const val =
            copy[idx + c] * centerWeight -
            k * (copy[top + c] + copy[bottom + c] + copy[left + c] + copy[right + c]);
          pixels[idx + c] = Math.min(255, Math.max(0, val));
        }
      }
    }
    ctx.putImageData(imgData, 0, 0);
  }

  if ((settings.temperature || 0) !== 0) {
    const tempFactor = settings.temperature / 100;
    const imgData = ctx.getImageData(0, 0, width, height);
    const pixels = imgData.data;

    for (let i = 0; i < pixels.length; i += 4) {
      if (tempFactor > 0) {
        pixels[i] = Math.min(255, pixels[i] + tempFactor * 25);
        pixels[i + 2] = Math.max(0, pixels[i + 2] - tempFactor * 15);
      } else {
        pixels[i + 2] = Math.min(255, pixels[i + 2] + Math.abs(tempFactor) * 25);
        pixels[i] = Math.max(0, pixels[i] - Math.abs(tempFactor) * 15);
      }
    }
    ctx.putImageData(imgData, 0, 0);
  }

  return canvas.toDataURL('image/png');
}

/**
 * Bulk Processing ZIP generator using JSZip
 */
async function generateZipArchive(items, onProgress) {
  if (typeof JSZip === 'undefined') {
    throw new Error('JSZip library is not loaded');
  }
  const zip = new JSZip();

  items.forEach((item, index) => {
    const blob = dataURLtoBlob(item.dataUrl);
    const ext = item.dataUrl.includes('image/jpeg') ? '.jpg' : item.dataUrl.includes('image/webp') ? '.webp' : '.png';
    const filename = item.name.replace(/\.[^/.]+$/, '') + '-vivel' + ext;
    zip.file(filename, blob);

    if (onProgress) {
      onProgress(Math.round(((index + 1) / items.length) * 50));
    }
  });

  return await zip.generateAsync({ type: 'blob' }, (metadata) => {
    if (onProgress) {
      onProgress(50 + Math.round((metadata.percent / 100) * 50));
    }
  });
}
