/**
 * Vivel AI - Shared UI Components & Layout Handlers
 */

function renderHeader(activePage) {
  const container = document.getElementById('header-container');
  if (!container) return;

  const navItems = [
    { id: 'watermark-remover', name: 'Watermark Remover', href: 'watermark-remover.html' },
    { id: 'background-remover', name: 'Background Remover', href: 'background-remover.html' },
    { id: 'image-resizer', name: 'Image Resizer', href: 'image-resizer.html' },
    { id: 'image-enhancer', name: 'Image Enhancer', href: 'image-enhancer.html' },
    { id: 'bulk-tools', name: 'Bulk Tools', href: 'bulk-tools.html' },
    { id: 'contact', name: 'Contact', href: 'contact.html' },
  ];

  const desktopNavHtml = navItems
    .map((item) => {
      const isActive = activePage === item.id;
      return `<a href="${item.href}" class="text-xs font-semibold transition-colors px-3 py-1.5 rounded-lg ${
        isActive
          ? 'bg-blue-50 text-blue-600 border border-blue-200/60 font-bold'
          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
      }">${item.name}</a>`;
    })
    .join('');

  const mobileNavHtml = navItems
    .map((item) => {
      const isActive = activePage === item.id;
      return `<a href="${item.href}" class="block text-sm font-semibold transition-colors px-4 py-2.5 rounded-xl ${
        isActive
          ? 'bg-blue-50 text-blue-600 font-bold border border-blue-200/60'
          : 'text-slate-600 hover:bg-slate-100'
      }">${item.name}</a>`;
    })
    .join('');

  container.innerHTML = `
    <header class="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-200">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
          
          <!-- Logo -->
          <a href="index.html" class="flex items-center space-x-2.5 group">
            <div class="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-xs group-hover:bg-blue-700 transition-colors">
              <i data-lucide="sparkles" class="w-5 h-5"></i>
            </div>
            <div class="flex flex-col">
              <span class="text-base font-extrabold text-slate-900 tracking-tight leading-none">
                Vivel <span class="text-blue-600">AI</span>
              </span>
              <span class="text-[10px] font-medium text-slate-500 tracking-wide uppercase mt-0.5">
                Image Suite
              </span>
            </div>
          </a>

          <!-- Desktop Nav -->
          <nav class="hidden md:flex items-center space-x-1">
            ${desktopNavHtml}
          </nav>

          <!-- Action Button -->
          <div class="hidden sm:flex items-center space-x-3">
            <a href="watermark-remover.html" class="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs transition-all flex items-center space-x-1.5">
              <span>Start Editing</span>
              <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </a>
          </div>

          <!-- Mobile Toggle -->
          <div class="md:hidden flex items-center">
            <button id="mobile-menu-toggle" class="p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100">
              <i data-lucide="menu" class="w-6 h-6"></i>
            </button>
          </div>

        </div>
      </div>

      <!-- Mobile Dropdown -->
      <div id="mobile-menu" class="hidden md:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-1">
        ${mobileNavHtml}
        <div class="pt-2">
          <a href="watermark-remover.html" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2.5 rounded-xl text-center block shadow-xs">
            Start Editing Now
          </a>
        </div>
      </div>
    </header>
  `;

  // Toggle mobile menu
  const toggleBtn = document.getElementById('mobile-menu-toggle');
  const mobileMenu = document.getElementById('mobile-menu');
  if (toggleBtn && mobileMenu) {
    toggleBtn.addEventListener('click', () => {
      mobileMenu.classList.toggle('hidden');
    });
  }

  if (window.lucide) {
    lucide.createIcons();
  }
}

function renderFooter() {
  const container = document.getElementById('footer-container');
  if (!container) return;

  container.innerHTML = `
    <footer class="bg-slate-900 text-slate-300 border-t border-slate-800 mt-20">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          <!-- Brand Info -->
          <div class="space-y-4 md:col-span-1">
            <div class="flex items-center space-x-2">
              <div class="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                <i data-lucide="sparkles" class="w-4 h-4"></i>
              </div>
              <span class="text-lg font-bold text-white tracking-tight">Vivel AI</span>
            </div>
            <p class="text-xs text-slate-400 leading-relaxed">
              Fast, high-precision browser-based image editing suite. Erase watermarks, cut out backgrounds, resize dimensions, and boost image clarity.
            </p>
          </div>

          <!-- Quick Links -->
          <div class="space-y-3">
            <h4 class="text-xs font-bold text-white uppercase tracking-wider">Navigation</h4>
            <ul class="space-y-2 text-xs">
              <li><a href="index.html" class="hover:text-blue-400 transition-colors">Home</a></li>
              <li><a href="watermark-remover.html" class="hover:text-blue-400 transition-colors">Watermark Remover</a></li>
              <li><a href="background-remover.html" class="hover:text-blue-400 transition-colors">Background Remover</a></li>
              <li><a href="image-resizer.html" class="hover:text-blue-400 transition-colors">Image Resizer</a></li>
            </ul>
          </div>

          <!-- Advanced Tools -->
          <div class="space-y-3">
            <h4 class="text-xs font-bold text-white uppercase tracking-wider">Advanced Tools</h4>
            <ul class="space-y-2 text-xs">
              <li><a href="image-enhancer.html" class="hover:text-blue-400 transition-colors">Image Enhancer</a></li>
              <li><a href="bulk-tools.html" class="hover:text-blue-400 transition-colors">Bulk Batch Tools</a></li>
              <li><a href="contact.html" class="hover:text-blue-400 transition-colors">Contact Support</a></li>
            </ul>
          </div>

          <!-- Security Notice -->
          <div class="space-y-3">
            <h4 class="text-xs font-bold text-white uppercase tracking-wider">Privacy & Security</h4>
            <p class="text-xs text-slate-400 leading-relaxed">
              Processed directly in your web browser. Confidential and secure.
            </p>
            <div class="pt-1 flex items-center space-x-2 text-blue-400 text-xs font-semibold">
              <i data-lucide="shield-check" class="w-4 h-4"></i>
              <span>High Security Standard</span>
            </div>
          </div>

        </div>

        <div class="border-t border-slate-800 pt-6 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-4">
          <p>© ${new Date().getFullYear()} Vivel AI. All rights reserved.</p>
          <div class="flex items-center space-x-6">
            <a href="contact.html" class="hover:text-slate-300 transition-colors">Contact</a>
            <a href="index.html#faqs" class="hover:text-slate-300 transition-colors">FAQs</a>
          </div>
        </div>

      </div>
    </footer>
  `;

  if (window.lucide) {
    lucide.createIcons();
  }
}

function initSamplePicker(containerId, categoryFilter, onSelectSample) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const samples = generateSampleImages().filter(
    (s) => !categoryFilter || s.category === categoryFilter || s.category === 'general'
  );

  container.innerHTML = `
    <div class="bg-slate-50 border border-slate-200 rounded-xl p-4">
      <div class="flex items-center justify-between mb-3">
        <div class="flex items-center space-x-2 text-blue-600 text-xs font-semibold uppercase tracking-wider">
          <i data-lucide="sparkles" class="w-3.5 h-3.5"></i>
          <span>Or Try A Demo Sample Image</span>
        </div>
        <span class="text-[11px] text-slate-500">Click to load instantly</span>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
        ${samples
          .map(
            (sample) => `
          <button
            data-sample-id="${sample.id}"
            class="sample-btn group relative bg-white border border-slate-200 rounded-lg p-2 text-left hover:border-blue-500 hover:bg-slate-50 transition-all flex items-center space-x-3 overflow-hidden focus:outline-none shadow-xs cursor-pointer"
          >
            <div class="w-14 h-14 rounded-md overflow-hidden bg-slate-100 shrink-0 border border-slate-200">
              <img
                src="${sample.dataUrl}"
                alt="${sample.name}"
                class="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
            </div>
            <div class="min-w-0 flex-1">
              <h4 class="text-slate-900 text-xs font-semibold truncate group-hover:text-blue-600 transition-colors">
                ${sample.name}
              </h4>
              <p class="text-[11px] text-slate-500 line-clamp-2 leading-tight mt-0.5">
                ${sample.description}
              </p>
            </div>
          </button>
        `
          )
          .join('')}
      </div>
    </div>
  `;

  container.querySelectorAll('.sample-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-sample-id');
      const sample = samples.find((s) => s.id === id);
      if (sample && onSelectSample) {
        onSelectSample(sample.dataUrl, sample.name);
      }
    });
  });

  if (window.lucide) {
    lucide.createIcons();
  }
}

function initBeforeAfterSlider(containerId, { originalUrl, processedUrl, downloadFilename, title }) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const filename = downloadFilename || 'vivel-ai-output.png';
  const displayTitle = title || 'Interactive Comparison';

  container.innerHTML = `
    <div class="bg-slate-50 border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
      <!-- Controls Bar -->
      <div class="bg-white px-4 py-3 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
        <div class="flex items-center space-x-2">
          <span class="text-slate-900 font-semibold text-sm">${displayTitle}</span>
        </div>

        <div class="flex items-center space-x-2 text-xs">
          <!-- View Mode Toggle -->
          <div class="bg-slate-100 p-1 rounded-lg border border-slate-200 flex items-center space-x-1">
            <button
              id="btn-mode-slider"
              class="px-2.5 py-1 rounded flex items-center space-x-1 font-medium transition-colors bg-blue-600 text-white shadow-xs"
            >
              <i data-lucide="split-square-vertical" class="w-3.5 h-3.5"></i>
              <span>Split Slider</span>
            </button>
            <button
              id="btn-mode-side"
              class="px-2.5 py-1 rounded flex items-center space-x-1 font-medium transition-colors text-slate-600 hover:text-slate-900"
            >
              <i data-lucide="columns" class="w-3.5 h-3.5"></i>
              <span>Side-by-Side</span>
            </button>
          </div>

          <!-- Zoom Buttons -->
          <div class="bg-slate-100 p-1 rounded-lg border border-slate-200 flex items-center space-x-1">
            <button id="btn-zoom-out" class="p-1 text-slate-600 hover:text-slate-900 transition-colors" title="Zoom Out">
              <i data-lucide="zoom-out" class="w-3.5 h-3.5"></i>
            </button>
            <span id="zoom-value" class="text-slate-800 font-mono px-1 font-semibold">100%</span>
            <button id="btn-zoom-in" class="p-1 text-slate-600 hover:text-slate-900 transition-colors" title="Zoom In">
              <i data-lucide="zoom-in" class="w-3.5 h-3.5"></i>
            </button>
            <button id="btn-zoom-reset" class="p-1 text-slate-600 hover:text-slate-900 transition-colors" title="Reset Zoom">
              <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
            </button>
          </div>

          <!-- Download Button -->
          <a
            href="${processedUrl}"
            download="${filename}"
            class="bg-blue-600 hover:bg-blue-700 text-white font-medium px-3.5 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors shadow-xs"
          >
            <i data-lucide="download" class="w-3.5 h-3.5"></i>
            <span>Download Result</span>
          </a>
        </div>
      </div>

      <!-- Comparison Content Wrapper -->
      <div id="comparison-wrapper" class="p-4 bg-slate-100/60 overflow-auto max-h-[600px] flex justify-center items-center">
        <!-- Split Slider View -->
        <div
          id="slider-box"
          class="relative select-none cursor-ew-resize overflow-hidden rounded-xl border border-slate-300 bg-checkerboard"
          style="transform: scale(1); transform-origin: center center;"
        >
          <img
            src="${processedUrl}"
            alt="Processed Result"
            class="block max-w-full max-h-[500px] object-contain pointer-events-none"
          />

          <div
            id="slider-overlay"
            class="absolute top-0 left-0 bottom-0 overflow-hidden pointer-events-none"
            style="width: 50%;"
          >
            <img
              id="slider-orig-img"
              src="${originalUrl}"
              alt="Original Source"
              class="block max-w-none max-h-[500px] object-contain"
            />
          </div>

          <div
            id="slider-line"
            class="absolute top-0 bottom-0 w-0.5 bg-blue-600 shadow-[0_0_10px_rgba(37,99,235,0.5)] pointer-events-none"
            style="left: 50%;"
          >
            <div class="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-md border border-white font-bold text-xs">
              ↔
            </div>
          </div>

          <span class="absolute top-3 left-3 bg-slate-900/80 text-white text-xs font-medium px-2.5 py-1 rounded backdrop-blur border border-slate-700 pointer-events-none">
            Original (Before)
          </span>
          <span class="absolute top-3 right-3 bg-blue-600/90 text-white text-xs font-medium px-2.5 py-1 rounded backdrop-blur border border-blue-500 pointer-events-none">
            Processed (After)
          </span>
        </div>

        <!-- Side-by-Side View (hidden initially) -->
        <div id="side-box" class="hidden grid-cols-1 md:grid-cols-2 gap-4 w-full">
          <div class="space-y-2">
            <span class="text-xs font-semibold text-slate-600 block uppercase tracking-wider">Original</span>
            <div class="bg-white p-2 rounded-xl border border-slate-200 flex justify-center items-center">
              <img src="${originalUrl}" alt="Original" class="max-h-[400px] object-contain rounded-lg" />
            </div>
          </div>
          <div class="space-y-2">
            <span class="text-xs font-semibold text-blue-600 block uppercase tracking-wider">Processed Result</span>
            <div class="bg-white p-2 rounded-xl border border-slate-200 flex justify-center items-center">
              <img src="${processedUrl}" alt="Processed" class="max-h-[400px] object-contain rounded-lg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  if (window.lucide) {
    lucide.createIcons();
  }

  // Interactive logic
  const sliderBox = container.querySelector('#slider-box');
  const sliderOverlay = container.querySelector('#slider-overlay');
  const sliderOrigImg = container.querySelector('#slider-orig-img');
  const sliderLine = container.querySelector('#slider-line');
  const sideBox = container.querySelector('#side-box');

  const btnModeSlider = container.querySelector('#btn-mode-slider');
  const btnModeSide = container.querySelector('#btn-mode-side');

  const btnZoomIn = container.querySelector('#btn-zoom-in');
  const btnZoomOut = container.querySelector('#btn-zoom-out');
  const btnZoomReset = container.querySelector('#btn-zoom-reset');
  const zoomValSpan = container.querySelector('#zoom-value');

  let zoom = 1;
  let isDragging = false;

  function updateSliderWidth() {
    if (sliderBox && sliderOrigImg) {
      sliderOrigImg.style.width = sliderBox.clientWidth + 'px';
      sliderOrigImg.style.height = '100%';
    }
  }

  setTimeout(updateSliderWidth, 50);
  window.addEventListener('resize', updateSliderWidth);

  function setSliderPosition(clientX) {
    if (!sliderBox) return;
    const rect = sliderBox.getBoundingClientRect();
    const x = clientX - rect.left;
    let percentage = (x / rect.width) * 100;
    if (percentage < 0) percentage = 0;
    if (percentage > 100) percentage = 100;

    sliderOverlay.style.width = percentage + '%';
    sliderLine.style.left = percentage + '%';
  }

  sliderBox.addEventListener('mousedown', (e) => {
    isDragging = true;
    setSliderPosition(e.clientX);
  });
  window.addEventListener('mouseup', () => {
    isDragging = false;
  });
  sliderBox.addEventListener('mousemove', (e) => {
    if (isDragging) setSliderPosition(e.clientX);
  });
  sliderBox.addEventListener('touchmove', (e) => {
    if (e.touches.length > 0) setSliderPosition(e.touches[0].clientX);
  });

  // Mode toggling
  btnModeSlider.addEventListener('click', () => {
    sliderBox.classList.remove('hidden');
    sideBox.classList.add('hidden');
    sideBox.classList.remove('grid');

    btnModeSlider.className = 'px-2.5 py-1 rounded flex items-center space-x-1 font-medium transition-colors bg-blue-600 text-white shadow-xs';
    btnModeSide.className = 'px-2.5 py-1 rounded flex items-center space-x-1 font-medium transition-colors text-slate-600 hover:text-slate-900';
    updateSliderWidth();
  });

  btnModeSide.addEventListener('click', () => {
    sliderBox.classList.add('hidden');
    sideBox.classList.remove('hidden');
    sideBox.classList.add('grid');

    btnModeSide.className = 'px-2.5 py-1 rounded flex items-center space-x-1 font-medium transition-colors bg-blue-600 text-white shadow-xs';
    btnModeSlider.className = 'px-2.5 py-1 rounded flex items-center space-x-1 font-medium transition-colors text-slate-600 hover:text-slate-900';
  });

  // Zoom logic
  function applyZoom(z) {
    zoom = Math.max(0.5, Math.min(3, z));
    zoomValSpan.textContent = Math.round(zoom * 100) + '%';
    sliderBox.style.transform = `scale(${zoom})`;
    sideBox.style.transform = `scale(${zoom})`;
  }

  btnZoomIn.addEventListener('click', () => applyZoom(zoom + 0.25));
  btnZoomOut.addEventListener('click', () => applyZoom(zoom - 0.25));
  btnZoomReset.addEventListener('click', () => applyZoom(1));
}
